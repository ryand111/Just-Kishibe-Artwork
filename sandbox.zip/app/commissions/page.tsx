"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import Navbar from "@/lib/components/Navbar";

export default function Commissions() {
  const [mounted, setMounted] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [size, setSize] = useState("");
  const [description, setDescription] = useState("");

  // This ensures the browser has completely loaded before rendering the HTML
  useEffect(() => {
    setMounted(true);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg("");

    const { error } = await supabase
      .from("commissions")
      .insert([
        { 
          name: fullName, 
          email: email, 
          size: size, 
          description: description 
        }
      ]);

    setLoading(false);

    if (error) {
      console.error("Supabase error:", error.message);
      setErrorMsg("Something went wrong saving your request. Please try again!");
    } else {
      setSubmitted(true);
      setFullName("");
      setEmail("");
      setSize("");
      setDescription("");
    }
  };

  // Prevent rendering until page is safely mounted in the client browser
  if (!mounted) {
    return (
      <div className="min-h-screen bg-white text-black">
        <Navbar />
        <main className="max-w-4xl mx-auto px-8 py-16 text-center">
          <p className="text-gray-400">Loading form...</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-black">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-8 py-16">
        {/* Intro Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h1 className="text-4xl font-black mb-4 tracking-tight">Bespoke Commissions</h1>
          <p className="text-gray-600 text-lg leading-relaxed">
            Let's bring your vision to life. Whether you need a specific size for a blank wall or a custom color palette to match your room, I work closely with you to create a unique, meaningful piece of original art.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* The Process Steps */}
          <div className="md:col-span-1 space-y-8">
            <div>
              <span className="text-xs font-bold text-gray-400 tracking-wider block mb-1">STEP ONE</span>
              <h3 className="font-bold text-lg text-gray-900 mb-2">The Vision</h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                Tell me about your ideas! Share your preferred dimensions, overall vibe, color schemes, or any reference photos of my past work that stand out to you.
              </p>
            </div>
            <div>
              <span className="text-xs font-bold text-gray-400 tracking-wider block mb-1">STEP TWO</span>
              <h3 className="font-bold text-lg text-gray-900 mb-2">Pricing & Deposit</h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                Once we agree on the custom canvas size and overall design direction, I'll send over a personalized quote. A standard 50% deposit secures your spot in my studio calendar.
              </p>
            </div>
            <div>
              <span className="text-xs font-bold text-gray-400 tracking-wider block mb-1">STEP THREE</span>
              <h3 className="font-bold text-lg text-gray-900 mb-2">Creation & Delivery</h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                I'll send you progress updates while painting your piece. The final balance is only due once you are completely in love with the finished artwork!
              </p>
            </div>
          </div>

          {/* Inquiry Form */}
          <div className="md:col-span-2 bg-gray-50 p-8 rounded-xl border border-gray-100/80 shadow-sm">
            {submitted ? (
              <div className="text-center py-16">
                <span className="text-4xl">✨</span>
                <h3 className="text-xl font-bold mt-4 text-gray-900">Inquiry Received!</h3>
                <p className="text-sm text-gray-500 mt-2 max-w-sm mx-auto">
                  Thank you so much for reaching out. I'll review your project details and get back to you via email within 48 hours to discuss the next steps!
                </p>
                <button 
                  onClick={() => setSubmitted(false)} 
                  className="mt-6 text-sm font-semibold text-black underline hover:opacity-80"
                >
                  Submit another inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                {errorMsg && (
                  <div className="p-3 bg-red-50 text-red-600 rounded-lg text-sm font-medium">
                    {errorMsg}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold text-gray-400 tracking-wider mb-2">YOUR NAME</label>
                    <input 
                      required 
                      type="text" 
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full p-3 border border-gray-200 rounded-lg bg-white focus:outline-none focus:border-black transition-colors" 
                      placeholder="e.g. Sarah Murphy" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 tracking-wider mb-2">EMAIL ADDRESS</label>
                    <input 
                      required 
                      type="email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full p-3 border border-gray-200 rounded-lg bg-white focus:outline-none focus:border-black transition-colors" 
                      placeholder="e.g. sarah@example.com" 
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-400 tracking-wider mb-2">CANVAS SIZE OR DIMENSIONS</label>
                  <input 
                    type="text" 
                    value={size}
                    onChange={(e) => setSize(e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-lg bg-white focus:outline-none focus:border-black transition-colors" 
                    placeholder="e.g. 50x70cm, A1, or standard living room size" 
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-400 tracking-wider mb-2">PROJECT DESCRIPTION & IDEAS</label>
                  <textarea 
                    required
                    rows={5} 
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-lg bg-white text-sm focus:outline-none focus:border-black transition-colors" 
                    placeholder="Describe your vision, specific colors you love (or want to avoid), or the room this piece will live in..."
                  ></textarea>
                </div>

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full py-4 bg-black text-white text-sm font-semibold rounded-lg hover:bg-gray-800 transition-colors tracking-wide disabled:bg-gray-400"
                >
                  {loading ? "Sending Inquiry..." : "Send Commission Request"}
                </button>
              </form>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}