"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import Navbar from "@/lib/components/Navbar";

export default function AdminCommandCentre() {
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);

  // Form State for Creating a New Admin
  const [newAdminEmail, setNewAdminEmail] = useState("");
  const [newAdminPassword, setNewAdminPassword] = useState("");
  const [newAdminName, setNewAdminName] = useState("");
  const [actionLoading, setActionLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Verify if current logged-in user has admin rights
  useEffect(() => {
    const checkAdminStatus = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        router.push("/login");
        return;
      }

      // Query profiles table to ensure role is marked as admin
      const { data: profile, error } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();

      if (error || profile?.role !== "admin") {
        alert("Access Denied: You do not possess administrator level privileges.");
        router.push("/");
      } else {
        setIsAdmin(true);
      }
      setCheckingAuth(false);
    };

    checkAdminStatus();
  }, [router]);

  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading(true);
    setStatusMessage(null);

    try {
      // 1. Create the Auth record for the new administrator
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newAdminEmail.trim(),
        password: newAdminPassword,
      });

      if (authError) throw authError;

      if (authData?.user) {
        // 2. Insert profile record explicitly marked with the "admin" role flag
        const { error: profileError } = await supabase.from("profiles").insert([
          {
            id: authData.user.id,
            name: newAdminName.trim(),
            email: newAdminEmail.toLowerCase().trim(),
            role: "admin", // Sets the user explicitly as an administrator
          },
        ]);

        if (profileError) throw profileError;

        setStatusMessage({
          type: "success",
          text: `Success! Administrator profile created for ${newAdminEmail}.`,
        });
        
        // Reset state
        setNewAdminEmail("");
        setNewAdminPassword("");
        setNewAdminName("");
      }
    } catch (error: any) {
      setStatusMessage({
        type: "error",
        text: error.message || "Failed to create administrator account.",
      });
    } finally {
      setActionLoading(false);
    }
  };

  if (checkingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 text-sm text-gray-500 font-sans">
        Authenticating Secure Channel...
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-neutral-950 text-white font-sans selection:bg-white selection:text-black">
      <Navbar />

      <main className="max-w-4xl mx-auto px-6 py-12 space-y-12 animate-in fade-in duration-300">
        {/* Header Block */}
        <div className="border-b border-neutral-800 pb-6">
          <h1 className="text-4xl font-bold tracking-tight">Admin Command Centre</h1>
          <p className="text-sm text-neutral-400 mt-1">
            System configuration operations, permission elevations, and manual item reservation parameters.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Action Module: Elevate/Create New Admin */}
          <div className="bg-neutral-900 border border-neutral-800 p-6 rounded-2xl space-y-4">
            <div>
              <h2 className="text-lg font-bold">Provision New Admin</h2>
              <p className="text-xs text-neutral-400">
                Directly writes a authenticated entity with full database table write clearances.
              </p>
            </div>

            {statusMessage && (
              <div
                className={`p-3 rounded-xl text-xs font-semibold text-center ${
                  statusMessage.type === "success"
                    ? "bg-emerald-950/50 border border-emerald-500/30 text-emerald-400"
                    : "bg-red-950/50 border border-red-500/30 text-red-400"
                }`}
              >
                {statusMessage.text}
              </div>
            )}

            <form onSubmit={handleCreateAdmin} className="space-y-3">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                  Admin Full Name
                </label>
                <input
                  type="text"
                  value={newAdminName}
                  onChange={(e) => setNewAdminName(e.target.value)}
                  className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-xl focus:outline-none text-sm focus:border-neutral-500 text-white transition-colors"
                  placeholder="System Supervisor"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                  Admin Email Address
                </label>
                <input
                  type="email"
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-xl focus:outline-none text-sm focus:border-neutral-500 text-white transition-colors"
                  placeholder="admin@domain.com"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                  Secure Admin Password
                </label>
                <input
                  type="password"
                  value={newAdminPassword}
                  onChange={(e) => setNewAdminPassword(e.target.value)}
                  className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-xl focus:outline-none text-sm focus:border-neutral-500 text-white transition-colors"
                  placeholder="••••••••"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={actionLoading}
                className="w-full bg-white text-black p-3 rounded-xl font-medium hover:bg-neutral-200 active:scale-[0.99] disabled:bg-neutral-700 disabled:text-neutral-500 transition-all text-sm mt-2"
              >
                {actionLoading ? "Deploying Privileges..." : "Create Admin Account"}
              </button>
            </form>
          </div>

          {/* Quick Stats/Utility Card */}
          <div className="bg-neutral-900/50 border border-neutral-800/60 p-6 rounded-2xl flex flex-col justify-between">
            <div className="space-y-2">
              <h2 className="text-lg font-bold text-neutral-400">Security Note</h2>
              <p className="text-xs text-neutral-500 leading-relaxed">
                Account generations bypass the standard customer directory tier. Make sure you have configured a 
                <code className="text-white px-1 py-0.5 bg-neutral-800 rounded mx-1">role</code> text column in your Supabase 
                <code className="text-white px-1 py-0.5 bg-neutral-800 rounded mx-1">profiles</code> data table schema to support structural authorization enforcement.
              </p>
            </div>
            
            <div className="text-xs text-neutral-600 border-t border-neutral-800 pt-4 mt-4">
              System Instance ID: <span className="font-mono text-neutral-400">ndgz7l-3000</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}