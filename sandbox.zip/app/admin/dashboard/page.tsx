"use strict";
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

interface AdminRecord {
  email: string;
  createdBy: string;
  createdAt: string;
  expiresAt: number | null;
}

interface ProfileRecord {
  id: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  created_at: string;
}

interface AuditLog {
  timestamp: string;
  actor: string;
  action: string;
  target: string;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [isMounted, setIsMounted] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  // Security Access Pool Lists
  const systemOwners = [
    "ryandunne2011@gmail.com",
    "sophiatoader22@gmail.com",
    "rohankishibe222324@gmail.com"
  ];
  const [authorizedAdmins, setAuthorizedAdmins] = useState<AdminRecord[]>([]);
  const [newAdminEmail, setNewAdminEmail] = useState("");
  const [clearanceDuration, setClearanceDuration] = useState("infinite");
  const [adminActionMessage, setAdminActionMessage] = useState<string | null>(null);

  // Maintenance & Automation Engine States
  const [isMaintenanceMode, setIsMaintenanceMode] = useState(false);
  const [systemPasskey, setSystemPasskey] = useState("Just Kishibe Artwork");
  const [passkeyRotationInput, setPasskeyRotationInput] = useState("");
  const [liveStatusText, setLiveStatusText] = useState<string>("System Operational");

  // Type Selector for Maintenance Tab
  const [maintenanceSetupType, setMaintenanceSetupType] = useState<"immediate" | "scheduled">("immediate");

  // Shared Calendar/Time States for Picker Configuration
  const [currentCalendarYear, setCurrentCalendarYear] = useState(2026);
  const [currentCalendarMonth, setCurrentCalendarMonth] = useState(5); // June
  const [activePickingTarget, setActivePickingTarget] = useState<"start" | "end">("start");

  // Chosen Specific Date/Time objects
  const [chosenStartDay, setChosenStartDay] = useState<number>(8);
  const [chosenStartHour, setChosenStartHour] = useState<string>("23");
  const [chosenStartMinute, setChosenStartMinute] = useState<string>("30");

  const [chosenEndDay, setChosenEndDay] = useState<number>(9);
  const [chosenEndHour, setChosenEndHour] = useState<string>("02");
  const [chosenEndMinute, setChosenEndMinute] = useState<string>("00");

  // MOTD Broadcaster States
  const [motdBroadcast, setMotdBroadcast] = useState("");
  const [motdEditingInput, setMotdEditingInput] = useState("");

  // Database Profiles & Security Logs
  const [customerDirectory, setCustomerDirectory] = useState<ProfileRecord[]>([]);
  const [searchCustomerQuery, setSearchCustomerQuery] = useState("");
  const [selectedProfile, setSelectedProfile] = useState<ProfileRecord | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [searchAuditQuery, setSearchAuditQuery] = useState("");

  // Commission Engine Extender States
  const [totalCommissionSlots, setTotalCommissionSlots] = useState(5);
  const [occupiedCommissionSlots, setOccupiedCommissionSlots] = useState(2);
  const [isCommissionQueueOpen, setIsCommissionQueueOpen] = useState(true);

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  useEffect(() => {
    setIsMounted(true);

    const isUnlocked = localStorage.getItem("terminal_unlocked") === "true";
    const mockEmail = localStorage.getItem("sb-mock-admin-email");

    if (!isUnlocked && !mockEmail) {
      alert("🔒 Unauthorized access. Terminal session is locked.");
      router.push("/");
      return;
    }

    setUserEmail((mockEmail || "").toLowerCase().trim());

    // Pull configuration registers
    setIsMaintenanceMode(localStorage.getItem("sys_maintenance_lockdown") === "true");

    const savedAdmins = localStorage.getItem("system_structural_admins");
    if (savedAdmins) {
      try { setAuthorizedAdmins(JSON.parse(savedAdmins)); } catch(e){}
    }

    setSystemPasskey(localStorage.getItem("sys_dynamic_passkey") || "Just Kishibe Artwork");
    
    const savedMotd = localStorage.getItem("sys_motd_broadcast") || "";
    setMotdBroadcast(savedMotd);
    setMotdEditingInput(savedMotd);

    setTotalCommissionSlots(Number(localStorage.getItem("sys_total_slots") || "5"));
    setOccupiedCommissionSlots(Number(localStorage.getItem("sys_occupied_slots") || "2"));
    setIsCommissionQueueOpen(localStorage.getItem("sys_queue_open") !== "false");
    
    const savedLogs = localStorage.getItem("sys_immutable_audit_logs");
    if (savedLogs) setAuditLogs(JSON.parse(savedLogs));

    supabase.from("profiles")
      .select("id, name, email, phone, created_at")
      .order("created_at", { ascending: false })
      .then(({ data }) => { if (data) setCustomerDirectory(data); });
  }, [router]);

  // AUTOMATION ENGINE BACKGROUND SCHEDULER TICKER
  useEffect(() => {
    if (!isMounted) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const latestLockdownValue = localStorage.getItem("sys_maintenance_lockdown") === "true";
      
      const configStart = localStorage.getItem("sys_maintenance_start_time") || "";
      const configEnd = localStorage.getItem("sys_maintenance_end_time") || "";

      let startTimeMs = configStart ? new Date(configStart).getTime() : 0;
      let endTimeMs = configEnd ? new Date(configEnd).getTime() : 0;

      // 1. AUTO-TRIGGER FUTURE START WINDOW
      if (startTimeMs && !latestLockdownValue && now >= startTimeMs) {
        if (!endTimeMs || now < endTimeMs) {
          localStorage.setItem("sys_maintenance_lockdown", "true");
          setIsMaintenanceMode(true);
          localStorage.removeItem("sys_maintenance_start_time"); // Clear start marker so it doesn't loop fire
          
          // Wipe out scheduled banner broadcast when maintenance begins
          localStorage.removeItem("sys_motd_broadcast");
          setMotdBroadcast("");
          setMotdEditingInput("");

          pushAuditLog("Automation Engine", "SCHEDULED START WINDOW REACHED: LOCKDOWN ENGAGED & BANNER REMOVED", new Date(startTimeMs).toISOString());
          return;
        }
      }

      // 2. AUTO-LIFT WHEN END TIME EXPIRATION IS BREACHED
      if (latestLockdownValue && endTimeMs && now >= endTimeMs) {
        localStorage.removeItem("sys_maintenance_start_time");
        localStorage.removeItem("sys_maintenance_end_time");
        localStorage.setItem("sys_maintenance_lockdown", "false");
        
        setIsMaintenanceMode(false);
        pushAuditLog("Automation Engine", "MAINTENANCE WINDOW OVER: AUTO-RESTORED ACCESSIBILITY", new Date(endTimeMs).toISOString());
        return;
      }

      // Update Ticker Status String Text
      if (latestLockdownValue) {
        if (endTimeMs) {
          const diff = endTimeMs - now;
          setLiveStatusText(`Lockdown Active (Auto-lifts in ${formatTimeDiff(diff)})`);
        } else {
          setLiveStatusText("Lockdown Active (Indefinite Manual Mode)");
        }
      } else {
        if (startTimeMs) {
          const diff = startTimeMs - now;
          setLiveStatusText(`Scheduled Event (Starts in ${formatTimeDiff(diff)})`);
        } else {
          setLiveStatusText("System Operational // Online");
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isMounted, isMaintenanceMode]);

  const formatTimeDiff = (ms: number) => {
    if (ms <= 0) return "0s";
    const totalSecs = Math.floor(ms / 1000);
    const mins = Math.floor((totalSecs / 60) % 60);
    const hours = Math.floor((totalSecs / 3600) % 24);
    const days = Math.floor(totalSecs / 86400);
    return `${days > 0 ? days + 'd ' : ''}${hours > 0 ? hours + 'h ' : ''}${mins}m ${totalSecs % 60}s`;
  };

  const currentEmailClean = userEmail?.toLowerCase().trim() || "";
  const isOwner = systemOwners.includes(currentEmailClean);

  const pushAuditLog = (actor: string, action: string, target: string) => {
    const newLog: AuditLog = {
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      actor, action, target
    };
    setAuditLogs((prev) => {
      const combined = [newLog, ...prev];
      localStorage.setItem("sys_immutable_audit_logs", JSON.stringify(combined));
      return combined;
    });
  };

  const handleMaintenanceConfigSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOwner) return;

    // IF WE ARE TURNING AN ACTIVE LOCKDOWN OFF
    if (isMaintenanceMode) {
      localStorage.removeItem("sys_maintenance_start_time");
      localStorage.removeItem("sys_maintenance_end_time");
      localStorage.setItem("sys_maintenance_lockdown", "false");
      setIsMaintenanceMode(false);
      pushAuditLog(currentEmailClean, "MANUAL OVERRIDE: TERMINATED MAINTENANCE", "System Restored");
      return;
    }

    // SCENARIO A: IMMEDIATE MAINTENANCE MODE LAUNCH (End Time is Mandatory)
    if (maintenanceSetupType === "immediate") {
      localStorage.removeItem("sys_maintenance_start_time");
      
      const endIso = new Date(
        currentCalendarYear, currentCalendarMonth, chosenEndDay,
        parseInt(chosenEndHour || "0"), parseInt(chosenEndMinute || "0")
      ).toISOString();

      if (new Date(endIso).getTime() <= Date.now()) {
        alert("⚠️ End time must be in the future!");
        return;
      }

      localStorage.setItem("sys_maintenance_end_time", endIso);
      localStorage.setItem("sys_maintenance_lockdown", "true");
      setIsMaintenanceMode(true);
      
      pushAuditLog(currentEmailClean, "LAUNCHED IMMEDIATE LOCKDOWN WITH MANDATORY AUTOMATED EXPIRY", endIso);
      alert("🛑 Site locked immediately!");
    } 
    
    // SCENARIO B: FUTURE SCHEDULED MAINTENANCE PIPELINE
    else {
      const startIso = new Date(
        currentCalendarYear, currentCalendarMonth, chosenStartDay,
        parseInt(chosenStartHour || "0"), parseInt(chosenStartMinute || "0")
      ).toISOString();

      const endIso = new Date(
        currentCalendarYear, currentCalendarMonth, chosenEndDay,
        parseInt(chosenEndHour || "0"), parseInt(chosenEndMinute || "0")
      ).toISOString();

      if (new Date(startIso).getTime() <= Date.now()) {
        alert("⚠️ Scheduled start time must be in the future!");
        return;
      }

      if (new Date(endIso).getTime() <= new Date(startIso).getTime()) {
        alert("⚠️ End time must happen after the start time configuration window!");
        return;
      }

      localStorage.setItem("sys_maintenance_start_time", startIso);
      localStorage.setItem("sys_maintenance_end_time", endIso);
      localStorage.setItem("sys_maintenance_lockdown", "false");
      setIsMaintenanceMode(false);

      // AUTOMATICALLY UPDATE AND PUSH BROADCAST TEXT BANNER
      const startDateFormatted = new Date(startIso).toLocaleDateString("en-GB", { day: '2-digit', month: '2-digit', year: 'numeric' });
      const startTimeFormatted = `${chosenStartHour.padStart(2, "0")}:${chosenStartMinute.padStart(2, "0")}`;
      const broadcastAlert = `Scheduled maintenance is due to take place on ${startDateFormatted} at ${startTimeFormatted}`;
      
      localStorage.setItem("sys_motd_broadcast", broadcastAlert);
      setMotdBroadcast(broadcastAlert);
      setMotdEditingInput(broadcastAlert);

      pushAuditLog(currentEmailClean, "QUEUED FUTURE SCHEDULED MAINTENANCE WINDOW & PUSHED MOTD BANNER", `Start: ${startIso} -> End: ${endIso}`);
      alert(`📅 Maintenance window successfully scheduled!\nStart: ${new Date(startIso).toLocaleString()}\nEnd: ${new Date(endIso).toLocaleString()}\n\n📢 Notice Broadcast Active.`);
    }
  };

  const handleCreateAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOwner) return;
    const targetEmail = newAdminEmail.toLowerCase().trim();
    if (!targetEmail) return;

    const newRecord: AdminRecord = {
      email: targetEmail,
      createdBy: currentEmailClean,
      createdAt: new Date().toLocaleDateString(),
      expiresAt: clearanceDuration === "1h" ? Date.now() + 3600000 : null,
    };

    const updated = [...authorizedAdmins, newRecord];
    setAuthorizedAdmins(updated);
    localStorage.setItem("system_structural_admins", JSON.stringify(updated));
    pushAuditLog(currentEmailClean, "Provisioned Access Pass", targetEmail);
    setNewAdminEmail("");
    setAdminActionMessage(`✅ Added ${targetEmail}`);
  };

  const handleRevokeAdmin = (targetEmail: string) => {
    if (!isOwner) return;
    const filtered = authorizedAdmins.filter(a => a.email !== targetEmail);
    setAuthorizedAdmins(filtered);
    localStorage.setItem("system_structural_admins", JSON.stringify(filtered));
    pushAuditLog(currentEmailClean, "Revoked Admin Seat Token", targetEmail);
  };

  const handleRotatePasskey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOwner || !passkeyRotationInput.trim()) return;
    localStorage.setItem("sys_dynamic_passkey", passkeyRotationInput.trim());
    setSystemPasskey(passkeyRotationInput.trim());
    setPasskeyRotationInput("");
    pushAuditLog(currentEmailClean, "Rotated Terminal Passkey Base", "System Config");
  };

  const commitMotdBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem("sys_motd_broadcast", motdEditingInput.trim());
    setMotdBroadcast(motdEditingInput.trim());
    pushAuditLog(currentEmailClean, "COMMITTED BANNER BROADCAST TEXT", motdEditingInput.trim() || "Wiped Broadcast");
  };

  const saveCommissionSettings = () => {
    localStorage.setItem("sys_total_slots", String(totalCommissionSlots));
    localStorage.setItem("sys_occupied_slots", String(occupiedCommissionSlots));
    localStorage.setItem("sys_queue_open", String(isCommissionQueueOpen));
    pushAuditLog(currentEmailClean, "UPDATED PUBLIC COMMISSION CONFIGURATION", `Open: ${isCommissionQueueOpen} (${occupiedCommissionSlots}/${totalCommissionSlots})`);
    alert("🎉 Commission metrics synchronized with live servers!");
  };

  const adjustMonthGrid = (direction: "prev" | "next") => {
    if (direction === "prev") {
      if (currentCalendarMonth === 0) { setCurrentCalendarMonth(11); setCurrentCalendarYear(y => y - 1); }
      else { setCurrentCalendarMonth(m => m - 1); }
    } else {
      if (currentCalendarMonth === 11) { setCurrentCalendarMonth(0); setCurrentCalendarYear(y => y + 1); }
      else { setCurrentCalendarMonth(m => m + 1); }
    }
  };

  const totalDaysInMonth = new Date(currentCalendarYear, currentCalendarMonth + 1, 0).getDate();
  const leadingOffsetSlots = new Date(currentCalendarYear, currentCalendarMonth, 1).getDay() === 0 ? 6 : new Date(currentCalendarYear, currentCalendarMonth, 1).getDay() - 1;

  if (!isMounted) return null;

  return (
    <div className="min-h-screen bg-neutral-950 text-white font-sans antialiased selection:bg-neutral-800 selection:text-white">
      
      {/* STEALTH COMMAND HEADER */}
      <header className="border-b border-neutral-800 bg-neutral-900/40 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-emerald-400 font-mono font-bold animate-pulse">●</span>
            <h1 className="text-sm font-bold uppercase tracking-widest font-mono text-neutral-200">Owner Terminal // Deck Suite</h1>
          </div>
          
          <button 
            onClick={() => router.push("/")}
            className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 text-neutral-300 text-xs font-bold px-4 py-2 rounded-xl transition-all font-mono"
          >
            ← RETURN TO WEBSITE
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8 space-y-6">

        {/* SYSTEM STATUS TELEMETRY GRID BANNER */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-neutral-500 block font-mono">Current Operator Profile</span>
              <span className="text-xs font-mono font-bold text-neutral-200 truncate block max-w-[320px]">{currentEmailClean}</span>
            </div>
            <span className="text-xl">🛡️</span>
          </div>

          <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-neutral-500 block font-mono">Automation Clock Engine Status</span>
              <span className="text-xs font-mono font-bold text-amber-400 block">{liveStatusText}</span>
            </div>
            <span className="text-xl">⏳</span>
          </div>
        </div>

        {/* UPPER GRID ELEMENTS */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* DYNAMIC PIPELINE CONTROL BOX: MAINTENANCE MODE CONFIGURATOR */}
          <div className="bg-neutral-900 border border-neutral-800/80 rounded-2xl p-5 space-y-4 lg:col-span-2">
            <div className="space-y-0.5">
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">🛠️ System Maintenance Automation Panel</h2>
              <p className="text-[11px] text-neutral-400">Deploy immediate locks or configure scheduled downtime events with dynamic auto-expiry lifters.</p>
            </div>

            <form onSubmit={handleMaintenanceConfigSubmit} className="space-y-4">
              {!isMaintenanceMode ? (
                <div className="space-y-4">
                  {/* CONFIGURATION SELECTOR STRIP */}
                  <div className="grid grid-cols-2 gap-2 bg-neutral-950 p-1 rounded-xl border border-neutral-850">
                    <button
                      type="button"
                      onClick={() => setMaintenanceSetupType("immediate")}
                      className={`py-1.5 rounded-lg text-xs font-bold font-mono transition-all ${maintenanceSetupType === "immediate" ? "bg-neutral-800 text-white border border-neutral-700 shadow" : "text-neutral-500 hover:text-neutral-300"}`}
                    >
                      Immediate Action Lock
                    </button>
                    <button
                      type="button"
                      onClick={() => setMaintenanceSetupType("scheduled")}
                      className={`py-1.5 rounded-lg text-xs font-bold font-mono transition-all ${maintenanceSetupType === "scheduled" ? "bg-neutral-800 text-white border border-neutral-700 shadow" : "text-neutral-500 hover:text-neutral-300"}`}
                    >
                      Scheduled Future Window
                    </button>
                  </div>

                  {/* CALENDAR DATE SELECTION HOOK GRID */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-neutral-950 rounded-2xl p-4 border border-neutral-850">
                    
                    {/* LEFT CANVAS: TIMEFRAME CALENDAR DISPLAY */}
                    <div>
                      <div className="flex items-center justify-between pb-2">
                        <span className="text-xs font-mono font-bold text-neutral-300">{monthNames[currentCalendarMonth]} {currentCalendarYear}</span>
                        <div className="flex items-center gap-3 text-neutral-400 text-xs">
                          <button type="button" onClick={() => adjustMonthGrid("prev")} className="hover:text-white">❮</button>
                          <button type="button" onClick={() => adjustMonthGrid("next")} className="hover:text-white">❯</button>
                        </div>
                      </div>

                      <div className="grid grid-cols-7 gap-y-1 text-center text-[9px] font-bold text-neutral-600 uppercase tracking-wider mb-1 font-mono">
                        <div>Mo</div><div>Tu</div><div>We</div><div>Th</div><div>Fr</div><div>Sa</div><div>Su</div>
                      </div>

                      <div className="grid grid-cols-7 gap-y-0.5 text-center font-mono">
                        {Array.from({ length: leadingOffsetSlots }).map((_, i) => <div key={`b-${i}`} className="text-transparent text-xs">0</div>)}
                        {Array.from({ length: totalDaysInMonth }).map((_, idx) => {
                          const day = idx + 1;
                          
                          // Determine selections depending on active editing targets
                          const isStartSelected = maintenanceSetupType === "scheduled" && day === chosenStartDay;
                          const isEndSelected = day === chosenEndDay;

                          return (
                            <button
                              key={`d-${day}`}
                              type="button"
                              onClick={() => {
                                if (maintenanceSetupType === "immediate") {
                                  setChosenEndDay(day);
                                } else {
                                  if (activePickingTarget === "start") setChosenStartDay(day);
                                  else setChosenEndDay(day);
                                }
                              }}
                              className="relative flex items-center justify-center aspect-square text-xs min-h-[28px]"
                            >
                              {isStartSelected ? (
                                <div className="absolute inset-0.5 bg-emerald-600 text-white font-bold rounded-lg flex items-center justify-center border border-emerald-400/20">{day}</div>
                              ) : isEndSelected ? (
                                <div className="absolute inset-0.5 bg-blue-600 text-white font-bold rounded-lg flex items-center justify-center border border-blue-400/20">{day}</div>
                              ) : (
                                <span className="text-neutral-400 hover:text-white">{day}</span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* RIGHT CANVAS: HOUR ADJUSTMENT STRIPS */}
                    <div className="flex flex-col justify-center space-y-4 border-t md:border-t-0 md:border-l border-neutral-900 pt-3 md:pt-0 md:pl-4 font-mono text-xs">
                      {maintenanceSetupType === "immediate" ? (
                        <div className="space-y-3">
                          <div className="bg-neutral-900/60 p-3 rounded-xl border border-neutral-850 space-y-2">
                            <div className="text-[10px] text-blue-400 font-bold uppercase tracking-wider">Configure Lift Expiry Point (Day {chosenEndDay})</div>
                            <div className="flex items-center justify-between">
                              <span className="text-neutral-500">Auto-Lift Time (24h)</span>
                              <div className="flex items-center bg-neutral-950 p-1 px-2 rounded border border-neutral-800">
                                <input type="text" maxLength={2} value={chosenEndHour} onChange={(e) => setChosenEndHour(e.target.value.replace(/\D/g, ""))} className="w-4 bg-transparent text-center font-bold focus:outline-none text-blue-400" />
                                <span className="text-neutral-600 px-0.5">:</span>
                                <input type="text" maxLength={2} value={chosenEndMinute} onChange={(e) => setChosenEndMinute(e.target.value.replace(/\D/g, ""))} className="w-4 bg-transparent text-center font-bold focus:outline-none text-blue-400" />
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {/* TARGET ACTIVE TOGGLE SUB-SELECTOR */}
                          <div className="grid grid-cols-2 gap-1.5 bg-neutral-900 p-1 rounded-lg border border-neutral-850 text-center text-[11px]">
                            <button
                              type="button"
                              onClick={() => setActivePickingTarget("start")}
                              className={`py-1 rounded font-bold ${activePickingTarget === "start" ? "bg-emerald-600 text-white" : "text-neutral-400"}`}
                            >
                              1. Pick Start Date/Time
                            </button>
                            <button
                              type="button"
                              onClick={() => setActivePickingTarget("end")}
                              className={`py-1 rounded font-bold ${activePickingTarget === "end" ? "bg-blue-600 text-white" : "text-neutral-400"}`}
                            >
                              2. Pick End Date/Time
                            </button>
                          </div>

                          <div className="bg-neutral-900/60 p-3 rounded-xl border border-neutral-850 space-y-2.5">
                            <div className="flex items-center justify-between">
                              <span className="text-neutral-400 font-bold">Start Node (Day {chosenStartDay})</span>
                              <div className="flex items-center bg-neutral-950 p-1 px-2 rounded border border-neutral-800">
                                <input type="text" maxLength={2} value={chosenStartHour} onChange={(e) => setChosenStartHour(e.target.value.replace(/\D/g, ""))} className="w-4 bg-transparent text-center text-emerald-400 font-bold focus:outline-none" />
                                <span className="text-neutral-600 px-0.5">:</span>
                                <input type="text" maxLength={2} value={chosenStartMinute} onChange={(e) => setChosenStartMinute(e.target.value.replace(/\D/g, ""))} className="w-4 bg-transparent text-center text-emerald-400 font-bold focus:outline-none" />
                              </div>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-neutral-400 font-bold">End Expiry (Day {chosenEndDay})</span>
                              <div className="flex items-center bg-neutral-950 p-1 px-2 rounded border border-neutral-800">
                                <input type="text" maxLength={2} value={chosenEndHour} onChange={(e) => setChosenEndHour(e.target.value.replace(/\D/g, ""))} className="w-4 bg-transparent text-center text-blue-400 font-bold focus:outline-none" />
                                <span className="text-neutral-600 px-0.5">:</span>
                                <input type="text" maxLength={2} value={chosenEndMinute} onChange={(e) => setChosenEndMinute(e.target.value.replace(/\D/g, ""))} className="w-4 bg-transparent text-center text-blue-400 font-bold focus:outline-none" />
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                  </div>
                </div>
              ) : (
                <div className="bg-red-950/20 p-5 border border-red-900/40 rounded-2xl text-center font-mono space-y-2">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-red-400 block">🚨 Global Lockdown Active</span>
                  <p className="text-xs text-neutral-300">
                    The public front-end is masked behind the security shield. All automation routines are active.
                  </p>
                </div>
              )}

              <button
                type="submit"
                className={`w-full py-3 px-4 rounded-xl font-bold font-mono text-xs uppercase tracking-wider transition-all border ${
                  isMaintenanceMode 
                    ? "bg-red-600 border-red-500 text-white hover:bg-red-500" 
                    : maintenanceSetupType === "immediate"
                      ? "bg-neutral-950 text-red-400 border-neutral-800 hover:bg-neutral-900"
                      : "bg-neutral-950 text-emerald-400 border-neutral-800 hover:bg-neutral-900"
                }`}
              >
                {isMaintenanceMode 
                  ? "⚡ FORCE TERMINATE ACTIVE LOCKDOWN" 
                  : maintenanceSetupType === "immediate" 
                    ? "🛑 ENGAGE IMMEDIATE LOCKDOWN WINDOW" 
                    : "📅 SCHEDULE AUTOMATED TIMEFRAME PIPELINE"
                }
              </button>
            </form>
          </div>

          {/* PORTFOLIO COMMISSION MANAGER ACCORDION */}
          <div className="bg-neutral-900 border border-neutral-800/80 rounded-2xl p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="space-y-0.5">
                <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">🎨 Artwork Commission Slots</h2>
                <p className="text-[11px] text-neutral-400">Sync portfolio availability blocks.</p>
              </div>

              <div className="flex items-center justify-between bg-neutral-950 p-2 rounded-xl border border-neutral-850">
                <span className="text-xs font-mono text-neutral-400">Accepting Queries</span>
                <button 
                  onClick={() => setIsCommissionQueueOpen(!isCommissionQueueOpen)}
                  className={`text-[10px] uppercase font-black px-2.5 py-1 rounded-md font-mono ${isCommissionQueueOpen ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}
                >
                  {isCommissionQueueOpen ? "OPEN" : "LOCKED"}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-850">
                  <span className="text-[10px] text-neutral-500 block uppercase font-bold">Filled Slots</span>
                  <div className="flex items-center gap-2 mt-1">
                    <button type="button" onClick={() => setOccupiedCommissionSlots(Math.max(0, occupiedCommissionSlots - 1))} className="text-neutral-400 hover:text-white font-black">-</button>
                    <span className="font-bold text-neutral-200">{occupiedCommissionSlots}</span>
                    <button type="button" onClick={() => setOccupiedCommissionSlots(Math.min(totalCommissionSlots, occupiedCommissionSlots + 1))} className="text-neutral-400 hover:text-white font-black">+</button>
                  </div>
                </div>
                <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-850">
                  <span className="text-[10px] text-neutral-500 block uppercase font-bold">Capacity</span>
                  <div className="flex items-center gap-2 mt-1">
                    <button type="button" onClick={() => setTotalCommissionSlots(Math.max(1, totalCommissionSlots - 1))} className="text-neutral-400 hover:text-white font-black">-</button>
                    <span className="font-bold text-neutral-200">{totalCommissionSlots}</span>
                    <button type="button" onClick={() => setTotalCommissionSlots(totalCommissionSlots + 1)} className="text-neutral-400 hover:text-white font-black">+</button>
                  </div>
                </div>
              </div>
            </div>

            <button type="button" onClick={saveCommissionSettings} className="w-full bg-neutral-800 border border-neutral-700 hover:bg-neutral-700 font-bold font-mono text-[11px] py-2 rounded-xl text-neutral-300">
              Sync Commission Metrics
            </button>
          </div>

        </div>

        {/* BROADCAST AND PASSKEY ROTATION STRIPS */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* GLOBAL BROADCAST BANNER MATRIX */}
          <div className="bg-neutral-900 border border-neutral-800/80 rounded-2xl p-5 space-y-4 md:col-span-2">
            <div className="space-y-0.5">
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">📢 Global Broadcast Banner Matrix</h2>
              <p className="text-[11px] text-neutral-400">Push alert banners directly above store headers.</p>
            </div>
            <form onSubmit={commitMotdBroadcast} className="space-y-3">
              <textarea
                value={motdEditingInput}
                onChange={(e) => setMotdEditingInput(e.target.value)}
                placeholder="Type dynamic alert stream text..."
                className="w-full h-16 p-3 bg-neutral-950 border border-neutral-800 rounded-xl text-xs focus:outline-none font-mono text-neutral-200"
              />
              <div className="flex items-center gap-2 justify-between">
                <div className="text-[11px] font-mono text-neutral-500">
                  Status: {motdBroadcast ? <span className="text-emerald-400 font-bold">LIVE ON SITE</span> : <span className="text-neutral-600">MUTED</span>}
                </div>
                <div className="flex items-center gap-2">
                  {motdBroadcast && (
                    <button
                      type="button"
                      onClick={() => { setMotdEditingInput(""); localStorage.removeItem("sys_motd_broadcast"); setMotdBroadcast(""); }}
                      className="bg-neutral-950 border border-neutral-800 hover:bg-red-950/20 text-red-400 font-bold font-mono text-xs px-3 py-1.5 rounded-xl transition-all"
                    >
                      Wipe Clear
                    </button>
                  )}
                  <button type="submit" className="bg-white text-black font-bold font-mono text-xs px-4 py-1.5 rounded-xl hover:bg-neutral-200 transition-all">
                    Commit Broadcast
                  </button>
                </div>
              </div>
            </form>
          </div>

          {/* GATEWAY PASSKEY BASE SECTOR */}
          <div className="bg-neutral-900 border border-neutral-800/80 rounded-2xl p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-2">
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">🔑 Gateway Core Key Rotation</h2>
              {isOwner ? (
                <form onSubmit={handleRotatePasskey} className="space-y-2">
                  <input 
                    type="text" 
                    value={passkeyRotationInput}
                    onChange={(e) => setPasskeyRotationInput(e.target.value)}
                    placeholder="Enter new passkey phrase..."
                    className="w-full p-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs focus:outline-none font-mono text-neutral-200"
                  />
                  <button type="submit" className="w-full bg-neutral-800 border border-neutral-700 font-bold font-mono text-xs py-1.5 rounded-xl text-neutral-200 hover:bg-neutral-700">
                    Commit Rotation
                  </button>
                </form>
              ) : (
                <div className="bg-neutral-950/40 border border-neutral-850 p-2 rounded-xl text-center text-xs text-neutral-500 font-mono">Locked</div>
              )}
            </div>
            <div className="bg-neutral-950 p-2 rounded-xl border border-neutral-850 font-mono text-[10px] flex justify-between">
              <span className="text-neutral-500">ACTIVE OVERRIDE:</span>
              <span className="text-neutral-300 italic">"{systemPasskey}"</span>
            </div>
          </div>

        </div>

        {/* BOTTOM GRIDS */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ADMINISTRATIVE CLEARANCE MATRIX */}
          <div className="bg-neutral-900 border border-neutral-800/80 rounded-2xl p-5 space-y-4">
            <div className="space-y-0.5">
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">👥 Clearance Authorization Matrix</h2>
              <p className="text-[11px] text-neutral-400">Delegate temporary administrative seats.</p>
            </div>
            {isOwner ? (
              <form onSubmit={handleCreateAdmin} className="space-y-2">
                <input type="email" value={newAdminEmail} onChange={(e) => setNewAdminEmail(e.target.value)} placeholder="operator@domain.com" className="w-full p-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs focus:outline-none font-mono" required />
                <button type="submit" className="w-full bg-white text-black font-bold font-mono text-xs py-2 rounded-xl hover:bg-neutral-200 transition-all">Provision Access Pass</button>
                {adminActionMessage && <p className="text-[10px] text-center font-mono text-neutral-400">{adminActionMessage}</p>}
              </form>
            ) : (
              <div className="bg-neutral-950/40 border border-neutral-850 p-4 rounded-xl text-center text-xs text-neutral-500 font-mono">Owner Token Required</div>
            )}
            <div className="space-y-1.5 max-h-[100px] overflow-y-auto font-mono">
              {authorizedAdmins.map((admin) => (
                <div key={admin.email} className="flex items-center justify-between bg-neutral-950 p-2 rounded-lg border border-neutral-850 text-[11px]">
                  <span className="truncate text-neutral-300 pr-2">{admin.email}</span>
                  {isOwner && <button onClick={() => handleRevokeAdmin(admin.email)} className="text-red-400 text-[10px] hover:underline font-bold">Revoke</button>}
                </div>
              ))}
            </div>
          </div>

          {/* PROFILE DATABASE LOGGER */}
          <div className="bg-neutral-900 border border-neutral-800/80 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-xs font-mono uppercase tracking-wider text-neutral-400">Database Profile Log</h3>
              <input type="text" placeholder="Search..." value={searchCustomerQuery} onChange={(e) => setSearchCustomerQuery(e.target.value)} className="bg-neutral-950 border border-neutral-800 rounded-lg px-2 py-1 text-xs text-neutral-200 focus:outline-none w-28 font-mono" />
            </div>
            <div className="rounded-xl border border-neutral-850 bg-neutral-950 max-h-[160px] overflow-y-auto text-[11px] font-mono">
              <table className="w-full text-left border-collapse">
                <tbody className="divide-y divide-neutral-900">
                  {customerDirectory.filter(c => c.name?.toLowerCase().includes(searchCustomerQuery.toLowerCase())).map((cust) => (
                    <tr key={cust.id} className="hover:bg-neutral-900 cursor-pointer" onClick={() => setSelectedProfile(cust)}>
                      <td className="p-2 pl-3 font-bold text-neutral-200 truncate max-w-[100px]">{cust.name || "—"}</td>
                      <td className="p-2 text-neutral-400 truncate max-w-[130px]">{cust.email || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* SECURITY AUDIT STREAM */}
          <div className="bg-neutral-900 border border-neutral-800/80 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-xs font-mono uppercase tracking-wider text-neutral-400">Security Audit Trail</h3>
              <input type="text" placeholder="Search..." value={searchAuditQuery} onChange={(e) => setSearchAuditQuery(e.target.value)} className="bg-neutral-950 border border-neutral-800 rounded-lg px-2 py-1 text-xs text-neutral-200 focus:outline-none w-28 font-mono" />
            </div>
            <div className="rounded-xl border border-neutral-850 bg-neutral-950 p-2 max-h-[160px] overflow-y-auto font-mono text-[9px] space-y-1">
              {auditLogs.filter(l => `${l.actor} ${l.action}`.toLowerCase().includes(searchAuditQuery.toLowerCase())).map((log, index) => (
                <div key={index} className="p-1.5 bg-neutral-900/60 rounded border border-neutral-850 text-neutral-300">
                  <span className="text-neutral-500">[{log.timestamp}]</span> <span className="text-blue-400">{log.actor}</span>: <span className="text-amber-400">{log.action}</span> ➔ <span className="text-neutral-400 italic break-all">{log.target}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </main>

      {/* DETAILED PROFILE INSPECTION MODAL */}
      {selectedProfile && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-5 space-y-4 text-white relative font-mono">
            <button onClick={() => setSelectedProfile(null)} className="absolute top-4 right-4 text-neutral-400 hover:text-white">✕</button>
            <h3 className="text-xs uppercase font-bold tracking-widest text-neutral-400 border-b border-neutral-800 pb-2">Profile Deck Summary</h3>
            <div className="space-y-3 text-xs bg-neutral-950 p-4 rounded-xl border border-neutral-850">
              <div><span className="text-neutral-500 block">Identifier Name:</span> <span className="text-neutral-200 font-bold">{selectedProfile.name || "—"}</span></div>
              <div><span className="text-neutral-500 block">Routing Email:</span> <span className="text-neutral-200 font-bold break-all">{selectedProfile.email || "—"}</span></div>
              <div><span className="text-neutral-500 block">Contact Register:</span> <span className="text-neutral-200 font-bold">{selectedProfile.phone || "—"}</span></div>
              <div><span className="text-neutral-500 block">Initialization Date:</span> <span className="text-neutral-400">{new Date(selectedProfile.created_at).toLocaleDateString()}</span></div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}