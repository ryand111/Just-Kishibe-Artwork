"use strict";
"use client";

import { useState } from "react";

export default function AdminLogin() {
  const [email, setEmail] = useState("");
  const [secretPasskey, setSecretPasskey] = useState("");
  const [error, setError] = useState<string | null>(null);

  const allowedAdmins = [
    "ryandunne2011@gmail.com",
    "sophiatoader22@gmail.com",
    "rohankishibe222324@gmail.com",
  ];

  const handleAdminSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!allowedAdmins.includes(email.toLowerCase().trim())) {
      setError("Access Denied: This address is unauthorized.");
      return;
    }

    if (secretPasskey !== "Just Kishibe Artwork") {
      setError("Invalid System Passkey.");
      return;
    }

    // Assign operational keys directly to bypass routing pipeline traps
    localStorage.setItem("terminal_unlocked", "true");
    localStorage.setItem("sb-mock-admin-email", email.toLowerCase().trim());

    // Jump straight to the index page
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen bg-neutral-950 flex items-center justify-center p-6 font-sans select-none">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 p-8 rounded-2xl space-y-6 shadow-2xl">
        <div className="text-center space-y-1">
          <h1 className="text-2xl font-black tracking-tight text-white">Admin Terminal Gateway</h1>
          <p className="text-xs text-neutral-400">
            Initialize configuration settings.
          </p>
        </div>

        {error && (
          <div className="bg-red-950/50 border border-red-500/30 text-red-400 p-3 rounded-xl text-xs font-semibold text-center animate-shake">
            {error}
          </div>
        )}

        <form onSubmit={handleAdminSignIn} className="space-y-4">
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-1">
              Admin Registered Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-xl focus:outline-none text-sm focus:border-neutral-500 text-white transition-colors"
              placeholder="name@domain.com"
              required
            />
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-1">
              System Passkey
            </label>
            <input
              type="text"
              value={secretPasskey}
              onChange={(e) => setSecretPasskey(e.target.value)}
              className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-xl focus:outline-none text-sm focus:border-neutral-500 text-white transition-colors"
              placeholder="Just Kishibe Artwork"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-white text-black p-3 rounded-xl font-bold hover:bg-neutral-200 transition-all text-sm mt-2 shadow-md"
          >
            Authorize Connection
          </button>
        </form>
      </div>
    </div>
  );
}