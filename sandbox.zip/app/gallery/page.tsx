"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import Navbar from "@/lib/components/Navbar";

interface Artwork {
  id: number;
  description: string;
  price: number;
  image_url: string;
}

export default function Gallery() {
  const [artworks, setArtworks] = useState<Artwork[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchArtworks() {
      // Grabs everything from your Supabase artworks spreadsheet
      const { data, error } = await supabase.from("artworks").select("*");

      if (error) {
        console.error("Error fetching artwork:", error.message);
      } else if (data) {
        setArtworks(data);
      }
      setLoading(false);
    }

    fetchArtworks();
  }, []);

  return (
    <div className="min-h-screen bg-white text-black">
      <Navbar />

      <main className="max-w-7xl mx-auto px-8 py-12">
        <h1 className="text-4xl font-black mb-2">The Gallery</h1>
        <p className="text-gray-600 mb-10">
          Browse through original pieces and latest creations.
        </p>

        {loading ? (
          <p className="text-gray-500">Loading your masterpieces...</p>
        ) : artworks.length === 0 ? (
          <p className="text-gray-500">No artwork found in the database yet!</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {artworks.map((art) => (
              <div
                key={art.id}
                className="border border-gray-100 rounded-xl overflow-hidden shadow-sm"
              >
                <img
                  src={art.image_url}
                  alt="Artwork"
                  className="w-full h-72 object-cover bg-gray-50"
                />
                <div className="p-6">
                  <p className="text-gray-600 text-sm mb-4">
                    {art.description}
                  </p>
                  <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                    <div>
                      <span className="text-xs text-gray-400 block font-medium">
                        PRICE
                      </span>
                      <span className="text-xl font-bold">€{art.price}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
