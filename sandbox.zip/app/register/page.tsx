"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import Link from "next/link";
import Navbar from "@/lib/components/Navbar";

// Common country prefixes
const COUNTRY_PREFIXES = [
  { code: "+1", country: "US/CA" },
  { code: "+44", country: "UK" },
  { code: "+353", country: "IE" },
  { code: "+61", country: "AU" },
  { code: "+33", country: "FR" },
  { code: "+49", country: "DE" },
  { code: "+91", country: "IN" },
  { code: "+81", country: "JP" },
  { code: "+64", country: "NZ" },
  { code: "+27", country: "ZA" },
];

export default function Register() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phonePrefix, setPhonePrefix] = useState("+353"); // 👈 Changed default prefix here
  const [phoneNumber, setPhoneNumber] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Restrict telephone input to numbers only
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const numericValue = value.replace(/\D/g, ""); // Strips out any non-numeric characters
    setPhoneNumber(numericValue);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage(null);

    // Basic Validation Guardrails
    if (!name || !email || !phoneNumber || !password) {
      setErrorMessage("Please fill in all required fields.");
      setLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage("Passwords do not match.");
      setLoading(false);
      return;
    }

    // Combine prefix and number for database storage (e.g., "+353871234567")
    const fullPhoneNumber = `${phonePrefix}${phoneNumber}`;

    try {
      // 1. Sign up user inside Supabase Auth Engine
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: email.trim(),
        password: password,
      });

      if (authError) throw authError;

      if (authData?.user) {
        // 2. Insert profile properties into the metadata profiles table
        const { error: profileError } = await supabase.from("profiles").insert([
          {
            id: authData.user.id,
            name: name.trim(),
            email: email.toLowerCase().trim(),
            phone: fullPhoneNumber,
          },
        ]);

        if (profileError) throw profileError;

        alert("Account registration successful! Welcome to the marketplace.");
        router.push("/shop");
      }
    } catch (error: any) {
      setErrorMessage(
        error.message || "An unexpected registration error occurred."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans selection:bg-neutral-900 selection:text-white transition-colors duration-300">
      <Navbar />

      <main className="max-w-md mx-auto px-4 py-16 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 space-y-6 transform transition-all duration-300 hover:shadow-md">
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-neutral-900 to-neutral-600 bg-clip-text text-transparent">
              Create Account
            </h1>
            <p className="text-sm text-gray-500">
              Join the collector directory and secure active art reservations.
            </p>
          </div>

          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs font-semibold text-center animate-bounce">
              ⚠️ {errorMessage}
            </div>
          )}

          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 block mb-1">
                Full Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm focus:border-neutral-900 focus:bg-white transition-all duration-200"
                placeholder="Jane Doe"
                required
                suppressHydrationWarning
              />
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 block mb-1">
                Email Address *
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm focus:border-neutral-900 focus:bg-white transition-all duration-200"
                placeholder="jane@example.com"
                required
                suppressHydrationWarning
              />
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 block mb-1">
                Phone Line *
              </label>
              <div className="flex gap-2">
                {/* Prefix Dropdown Selector */}
                <div className="relative flex-shrink-0 w-32">
                  <select
                    value={phonePrefix}
                    onChange={(e) => setPhonePrefix(e.target.value)}
                    className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm focus:border-neutral-900 focus:bg-white transition-all duration-200 appearance-none cursor-pointer pr-8"
                    suppressHydrationWarning
                  >
                    {COUNTRY_PREFIXES.map((item) => (
                      <option key={item.code} value={item.code}>
                        {item.code} ({item.country})
                      </option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-400">
                    <svg className="fill-current h-4 w-4" viewBox="0 0 20 20">
                      <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                    </svg>
                  </div>
                </div>

                {/* Numeric Input Field */}
                <input
                  type="text"
                  inputMode="numeric"
                  value={phoneNumber}
                  onChange={handlePhoneChange}
                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm focus:border-neutral-400 transition-all duration-200"
                  placeholder="871234567"
                  required
                  suppressHydrationWarning
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 block mb-1">
                  Password *
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm focus:border-neutral-900 focus:bg-white transition-all duration-200"
                  placeholder="••••••••"
                  required
                  suppressHydrationWarning
                />
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 block mb-1">
                  Confirm *
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm focus:border-neutral-900 focus:bg-white transition-all duration-200"
                  placeholder="••••••••"
                  required
                  suppressHydrationWarning
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-black text-white p-3 rounded-xl font-medium hover:bg-neutral-800 active:scale-[0.98] disabled:bg-neutral-400 transition-all duration-150 text-sm mt-2 shadow-sm"
              suppressHydrationWarning
            >
              {loading ? "Registering Account..." : "Create Account"}
            </button>
          </form>

          <div className="text-center pt-2 border-t border-gray-100">
            <p className="text-xs text-gray-500">
              Already have an account?{" "}
              <Link
                href="/login"
                className="font-bold text-black hover:underline transition-all duration-150"
              >
                Sign In
              </Link>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
