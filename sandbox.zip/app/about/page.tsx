"use client";

import { useState, useEffect } from "react";
import Navbar from "@/lib/components/Navbar";

export default function About() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="min-h-screen bg-white text-black">
        <Navbar />
        <main className="max-w-4xl mx-auto px-8 py-16 text-center">
          <p className="text-gray-400">Loading...</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-black">
      <Navbar />

      <main className="max-w-5xl mx-auto px-8 py-16">
        {/* Two-Column Bio Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-24">
          
          {/* Left Side: Placeholder for your Photo */}
          <div className="bg-gray-100 aspect-[3/4] w-full rounded-xl flex items-center justify-center border border-gray-200 overflow-hidden shadow-sm group">
            {/* You can replace this whole div with an <img src="/your-photo.jpg" /> later! */}
            <div className="text-center p-6">
              <span className="text-3xl block mb-2">🎨</span>
              <p className="text-xs font-bold tracking-wider text-gray-400 uppercase">Your Studio Photo Here</p>
              <p className="text-xs text-gray-400 mt-1 max-w-[200px]">Add an image of you painting or a shot of your creative workspace.</p>
            </div>
          </div>

          {/* Right Side: Your Story */}
          <div className="space-y-6">
            <span className="text-xs font-bold text-gray-400 tracking-wider uppercase">The Artist</span>
            <h1 className="text-4xl font-black tracking-tight text-gray-900">
              Hi, I'm Sophia!
            </h1>
            <p className="text-gray-600 text-lg leading-relaxed">
              Based out of my home studio, I create contemporary pieces inspired by geometry, textures, and the way light interacts with raw canvas. What started as a personal creative escape has grown into a full-time passion for building custom art for homes around the world.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Every canvas is custom-built, primed, and layered with thought. I believe that art shouldn't just fill a blank space on a wall—it should completely shift the energy of a room and make a house feel deeply personal.
            </p>
            <div className="pt-4">
              <a 
                href="/commissions" 
                className="inline-block bg-black text-white px-6 py-3 text-sm font-semibold rounded-lg hover:bg-gray-800 transition-colors tracking-wide"
              >
                Work With Me
              </a>
            </div>
          </div>
        </div>

        <hr className="border-gray-100 my-16" />

        {/* Three Pillars / Values Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <h3 className="font-bold text-lg text-gray-900 mb-3">Premium Materials</h3>
            <p className="text-sm text-gray-500 leading-relaxed">
              I source high-grade heavy cotton duck canvas and professional-grade, highly pigmented acrylics so your artwork stays vibrant for a lifetime.
            </p>
          </div>
          <div>
            <h3 className="font-bold text-lg text-gray-900 mb-3">Collaborative Process</h3>
            <p className="text-sm text-gray-500 leading-relaxed">
              When ordering a commission, you aren't just buying a painting. You are part of the process from selecting the color swatches to signing off on the final reveal.
            </p>
          </div>
          <div>
            <h3 className="font-bold text-lg text-gray-900 mb-3">Worldwide Shipping</h3>
            <p className="text-sm text-gray-500 leading-relaxed">
              Each piece is meticulously wrapped in protective glassine paper, heavy-duty bubble wrap, and shipped in double-walled boxes to ensure safe arrival.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}