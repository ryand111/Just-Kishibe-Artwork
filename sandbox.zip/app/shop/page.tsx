"use strict";
"use client";

import { useState, useEffect, useRef } from "react";
import { supabase } from "@/lib/supabase";
import Navbar from "@/lib/components/Navbar";

function SoldCountdown({
  soldAt,
  onExpire,
}: {
  soldAt: string;
  onExpire: () => void;
}) {
  const [timeLeft, setTimeLeft] = useState("");

  useEffect(() => {
    if (!soldAt) return;
    const calculateTime = () => {
      const soldTime = new Date(soldAt).getTime();
      const expireTime = soldTime + 3 * 60 * 60 * 1000;
      const now = new Date().getTime();
      const difference = expireTime - now;

      if (difference <= 0) {
        setTimeLeft("Deleting...");
        onExpire();
        return;
      }
      const hours = Math.floor(difference / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);
      setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [soldAt, onExpire]);

  return (
    <div className="bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded-lg shadow-md flex items-center gap-1 animate-pulse">
      ⏱️ {timeLeft}
    </div>
  );
}

export default function Shop() {
  const [mounted, setMounted] = useState(false);
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("available");
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [artworks, setArtworks] = useState<any[]>([]);

  // Admin Context States
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentAdminEmail, setCurrentAdminEmail] = useState<string | null>(
    null
  );

  // Navigation & Filtering Filters
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [viewMode, setViewMode] = useState("grid");

  // Specs Configuration
  const [medium, setMedium] = useState("");
  const [dimensions, setDimensions] = useState("");
  const [year, setYear] = useState("");
  const [showSpecsForm, setShowSpecsForm] = useState(false);
  const [selectedLightboxImage, setSelectedLightboxImage] = useState<
    string | null
  >(null);

  // Modification States
  const [editingArtwork, setEditingArtwork] = useState<any | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editPrice, setEditPrice] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editStatus, setEditStatus] = useState("available");
  const [editMedium, setEditMedium] = useState("");
  const [editDimensions, setEditDimensions] = useState("");
  const [editYear, setEditYear] = useState("");
  const [editImageFiles, setEditImageFiles] = useState<File[]>([]);
  const [editExistingUrls, setEditExistingUrls] = useState<string[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const editFileInputRef = useRef<HTMLInputElement>(null);

  const getAdminName = (email: string | null) => {
    if (!email) return "Admin";
    const cleanEmail = email.toLowerCase().trim();
    if (cleanEmail === "ryandunne2011@gmail.com") return "Ryan";
    if (
      cleanEmail === "sophiatoader22@gmail.com" ||
      cleanEmail === "rohankishibe222324@gmail.com" ||
      cleanEmail === "spiatoader22@gmail.com"
    ) {
      return "Sophia";
    }
    return "Admin";
  };

  useEffect(() => {
    setMounted(true);
    fetchArtworks();

    const checkUserSession = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (session?.user?.email) {
        const email = session.user.email;
        setCurrentAdminEmail(email);
        const allowedAdmins = [
          "ryandunne2011@gmail.com",
          "sophiatoader22@gmail.com",
          "rohankishibe222324@gmail.com",
          "spiatoader22@gmail.com",
        ];
        if (allowedAdmins.includes(email.toLowerCase().trim())) {
          setIsAdmin(true);
        } else {
          setIsAdmin(false);
        }
      } else {
        setIsAdmin(false);
        setCurrentAdminEmail(null);
      }
    };

    checkUserSession();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user?.email) {
        const email = session.user.email;
        setCurrentAdminEmail(email);
        const allowedAdmins = [
          "ryandunne2011@gmail.com",
          "sophiatoader22@gmail.com",
          "rohankishibe222324@gmail.com",
          "spiatoader22@gmail.com",
        ];
        const verifyAdmin = allowedAdmins.includes(email.toLowerCase().trim());
        setIsAdmin(verifyAdmin);
      } else {
        setCurrentAdminEmail(null);
        setIsAdmin(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchArtworks = async () => {
    const { data, error } = await supabase
      .from("artworks")
      .select("*")
      .order("created_at", { ascending: false });
    if (!error && data) setArtworks(data);
  };

  const startEditing = (art: any) => {
    if (!isAdmin) return;
    setEditingArtwork(art);
    setEditTitle(art.title || "");
    setEditPrice(art.price ? art.price.toString() : "");
    setEditDescription(art.description || "");
    setEditStatus(art.status || "available");
    setEditMedium(art.medium || "");
    setEditDimensions(art.dimensions || "");
    setEditYear(art.year || "");
    setEditExistingUrls(art.image_url || []);
    setEditImageFiles([]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    if (!title || !price || imageFiles.length === 0) {
      alert("Please enter title, price, and select an image.");
      return;
    }
    setLoading(true);
    try {
      const publicUrlsArray: string[] = [];
      for (const file of imageFiles) {
        const fileExt = file.name.split(".").pop();
        const fileName = `${Math.random()}-${Date.now()}.${fileExt}`;
        const filePath = `artworks/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from("artworks")
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from("artworks")
          .getPublicUrl(filePath);
        publicUrlsArray.push(urlData.publicUrl);
      }

      let resInfo = null;
      if (status === "reserved") {
        const targetBuyer = prompt("Who is this item reserved for?", "Sarah");
        if (targetBuyer) {
          resInfo = `Reserved by ${getAdminName(
            currentAdminEmail
          )} for ${targetBuyer}`;
        }
      } else if (status === "sold") {
        const targetBuyer = prompt("Who is this item sold to?", "John");
        if (targetBuyer) {
          resInfo = `Sold to ${targetBuyer}`;
        }
      }

      const { error: dbError } = await supabase.from("artworks").insert([
        {
          title,
          price: parseFloat(price),
          description,
          status,
          image_url: publicUrlsArray,
          medium,
          dimensions,
          year,
          sold_at: status === "sold" ? new Date().toISOString() : null,
          reservation_info: resInfo,
        },
      ]);

      if (dbError) throw dbError;
      alert("Artwork listing published!");
      setTitle("");
      setPrice("");
      setDescription("");
      setStatus("available");
      setMedium("");
      setDimensions("");
      setYear("");
      setImageFiles([]);
      fetchArtworks();
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveChanges = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !editingArtwork) return;
    setLoading(true);
    try {
      const updatedUrls = [...editExistingUrls];
      for (const file of editImageFiles) {
        const fileExt = file.name.split(".").pop();
        const fileName = `${Math.random()}-${Date.now()}.${fileExt}`;
        const filePath = `artworks/${fileName}`;
        const { error: uploadError } = await supabase.storage
          .from("artworks")
          .upload(filePath, file);
        if (uploadError) throw uploadError;
        const { data: urlData } = supabase.storage
          .from("artworks")
          .getPublicUrl(filePath);
        updatedUrls.push(urlData.publicUrl);
      }

      let calculatedSoldAt = editingArtwork.sold_at;
      if (editStatus !== "sold") calculatedSoldAt = null;
      else if (!calculatedSoldAt) calculatedSoldAt = new Date().toISOString();

      let calculatedResInfo = editingArtwork.reservation_info;
      if (editStatus === "reserved") {
        if (editingArtwork.status !== "reserved") {
          const targetBuyer = prompt("Who is this item reserved for?", "Sarah");
          if (targetBuyer) {
            calculatedResInfo = `Reserved by ${getAdminName(
              currentAdminEmail
            )} for ${targetBuyer}`;
          }
        }
      } else if (editStatus === "sold") {
        if (editingArtwork.status !== "sold") {
          const targetBuyer = prompt("Who is this item sold to?", "John");
          if (targetBuyer) {
            calculatedResInfo = `Sold to ${targetBuyer}`;
          }
        }
      } else {
        calculatedResInfo = null;
      }

      const { error: dbError } = await supabase
        .from("artworks")
        .update({
          title: editTitle,
          price: parseFloat(editPrice),
          description: editDescription,
          status: editStatus,
          medium: editMedium,
          dimensions: editDimensions,
          year: editYear,
          image_url: updatedUrls,
          sold_at: calculatedSoldAt,
          reservation_info: calculatedResInfo,
        })
        .eq("id", editingArtwork.id);

      if (dbError) throw dbError;
      setEditingArtwork(null);
      fetchArtworks();
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!isAdmin || !confirm("Delete this listing permanently?")) return;
    try {
      await supabase.from("artworks").delete().eq("id", id);
      fetchArtworks();
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleUpdateStatus = async (id: string, newStatus: string) => {
    if (!isAdmin) return;
    const timestamp = newStatus === "sold" ? new Date().toISOString() : null;
    let resInfo: string | null = null;

    if (newStatus === "reserved") {
      const targetBuyer = prompt("Who is this item reserved for?");
      if (!targetBuyer) return;
      resInfo = `Reserved by ${getAdminName(
        currentAdminEmail
      )} for ${targetBuyer}`;
    } else if (newStatus === "sold") {
      const targetBuyer = prompt("Who is this item sold to?");
      if (!targetBuyer) return;
      resInfo = `Sold to ${targetBuyer}`;
    }

    setArtworks((prev) =>
      prev.map((art) =>
        art.id === id
          ? {
              ...art,
              status: newStatus,
              sold_at: timestamp,
              reservation_info: resInfo,
            }
          : art
      )
    );
    try {
      await supabase
        .from("artworks")
        .update({
          status: newStatus,
          sold_at: timestamp,
          reservation_info: resInfo,
        })
        .eq("id", id);
    } catch {
      fetchArtworks();
    }
  };

  const filteredAndSortedArtworks = artworks
    .filter((art) => (activeTab === "all" ? true : art.status === activeTab))
    .filter((art) =>
      !searchQuery
        ? true
        : art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (art.description &&
            art.description.toLowerCase().includes(searchQuery.toLowerCase()))
    )
    .sort((a, b) => {
      if (sortBy === "newest")
        return (
          new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        );
      if (sortBy === "oldest")
        return (
          new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        );
      if (sortBy === "price-low") return a.price - b.price;
      if (sortBy === "price-high") return b.price - a.price;
      return 0;
    });

  if (!mounted) return null;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans selection:bg-neutral-900 selection:text-white">
      <Navbar />

      {/* CORE MARKETPLACE INTERFACE FRAME */}
      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {isAdmin && (
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <div className="mb-4 border-b pb-2 flex justify-between items-center">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  ✨ Add New Artwork
                </h2>
                <span className="text-[10px] bg-black text-white px-2 py-0.5 rounded-md font-semibold">
                  👤 {getAdminName(currentAdminEmail)}
                </span>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                    Title *
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm"
                    placeholder="Artwork Title"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                      Price (€) *
                    </label>
                    <input
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm"
                      placeholder="0.00"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                      Status
                    </label>
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value)}
                      className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none h-[48px] text-sm"
                    >
                      <option value="available">Available</option>
                      <option value="reserved">Reserved</option>
                      <option value="sold">Sold</option>
                    </select>
                  </div>
                </div>

                <div className="border border-gray-100 rounded-xl overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setShowSpecsForm(!showSpecsForm)}
                    className="w-full p-3 bg-gray-50 text-left text-xs font-bold text-gray-600 uppercase tracking-wider flex justify-between items-center"
                  >
                    <span>
                      {showSpecsForm ? "▼ Hide Specs" : "▶ Add Optional Specs"}
                    </span>
                  </button>
                  {showSpecsForm && (
                    <div className="p-4 bg-white space-y-3 border-t border-gray-100">
                      <input
                        type="text"
                        value={medium}
                        onChange={(e) => setMedium(e.target.value)}
                        className="w-full p-2 bg-gray-50 border rounded-lg text-xs"
                        placeholder="Medium (e.g. Oil on Canvas)"
                      />
                      <input
                        type="text"
                        value={dimensions}
                        onChange={(e) => setDimensions(e.target.value)}
                        className="w-full p-2 bg-gray-50 border rounded-lg text-xs"
                        placeholder="Dimensions (e.g. 80x100cm)"
                      />
                      <input
                        type="text"
                        value={year}
                        onChange={(e) => setYear(e.target.value)}
                        className="w-full p-2 bg-gray-50 border rounded-lg text-xs"
                        placeholder="Year Production"
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                    Description
                  </label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl h-24 resize-none focus:outline-none text-sm"
                    placeholder="Product insights..."
                  />
                </div>

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="p-6 bg-gray-50 border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center hover:bg-gray-100 transition-all cursor-pointer group"
                >
                  <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">
                    📸
                  </span>
                  <p className="text-xs font-bold text-gray-600 uppercase tracking-wider text-center pointer-events-none">
                    {imageFiles.length > 0
                      ? `Selected ${imageFiles.length} files`
                      : "Choose Portfolio Art Images *"}
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) =>
                      e.target.files &&
                      setImageFiles(Array.from(e.target.files))
                    }
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-black text-white p-3 rounded-xl font-medium hover:bg-neutral-800 disabled:bg-neutral-400 transition-colors"
                >
                  {loading ? "Uploading..." : "Publish Listing"}
                </button>
              </form>
            </div>
          </div>
        )}

        <div
          className={`${isAdmin ? "lg:col-span-2" : "lg:col-span-3"} space-y-6`}
        >
          {/* Filtering Header Interface Controls */}
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex bg-gray-100 p-1 rounded-xl space-x-1">
                {["all", "available", "reserved", "sold"].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all ${
                      activeTab === tab
                        ? "bg-white text-black shadow-sm"
                        : "text-gray-500 hover:text-black"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2 border border-gray-100 bg-gray-50 p-1 rounded-xl">
                <button
                  onClick={() => setViewMode("grid")}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                    viewMode === "grid"
                      ? "bg-white text-black shadow-sm"
                      : "text-gray-400"
                  }`}
                >
                  ⬜ Grid
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                    viewMode === "list"
                      ? "bg-white text-black shadow-sm"
                      : "text-gray-400"
                  }`}
                >
                  ☰ List
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-gray-50">
              <input
                type="text"
                placeholder="🔍 Search gallery products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 text-sm rounded-xl focus:outline-none"
              />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-3 py-2 bg-gray-50 border border-gray-200 text-sm rounded-xl focus:outline-none"
              >
                <option value="newest">Latest Added</option>
                <option value="oldest">Oldest Added</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
            </div>
          </div>

          {/* Cards Portfolio Listings Output Container */}
          {viewMode === "grid" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredAndSortedArtworks.map((art) => (
                <div
                  key={art.id}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 flex flex-col group relative"
                >
                  <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 items-start">
                    {art.status === "available" && (
                      <span className="bg-emerald-500 text-white text-xs font-semibold px-2.5 py-1 rounded-full shadow-sm">
                        Available
                      </span>
                    )}
                    {art.status === "reserved" && (
                      <span className="bg-amber-500 text-white text-xs font-semibold px-2.5 py-1 rounded-full shadow-sm">
                        🔒 {art.reservation_info || "Reserved"}
                      </span>
                    )}
                    {art.status === "sold" && (
                      <span className="bg-red-500 text-white text-xs font-semibold px-2.5 py-1 rounded-full shadow-sm">
                        🛍️ {art.reservation_info || "Sold"}
                      </span>
                    )}
                    {isAdmin && art.status === "sold" && art.sold_at && (
                      <SoldCountdown
                        soldAt={art.sold_at}
                        onExpire={fetchArtworks}
                      />
                    )}
                  </div>

                  <div className="w-full aspect-[4/3] bg-gray-100 relative overflow-hidden cursor-zoom-in">
                    {art.image_url?.length > 0 ? (
                      <img
                        src={art.image_url[0]}
                        alt={art.title}
                        onClick={() =>
                          setSelectedLightboxImage(art.image_url[0])
                        }
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">
                        No Imagery Provided
                      </div>
                    )}
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-lg leading-snug">
                        {art.title}
                      </h3>
                      {(art.medium || art.dimensions || art.year) && (
                        <div className="flex flex-wrap gap-2 my-2 text-[11px] text-gray-400 font-medium">
                          {art.medium && (
                            <span className="bg-gray-50 px-2 py-0.5 rounded">
                              {art.medium}
                            </span>
                          )}
                          {art.dimensions && (
                            <span className="bg-gray-50 px-2 py-0.5 rounded">
                              {art.dimensions}
                            </span>
                          )}
                          {art.year && (
                            <span className="bg-gray-50 px-2 py-0.5 rounded">
                              {art.year}
                            </span>
                          )}
                        </div>
                      )}
                      <p className="text-gray-500 text-sm mt-1 line-clamp-2">
                        {art.description || "No item description catalogued."}
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-gray-50">
                      <span className="font-bold text-xl">€{art.price}</span>
                    </div>
                  </div>

                  {isAdmin && (
                    <div className="mx-4 mb-4 p-3 bg-gray-50 border border-gray-200 rounded-xl flex flex-col gap-2">
                      <div className="flex gap-1">
                        {["available", "reserved", "sold"].map((st) => (
                          <button
                            key={st}
                            onClick={() => handleUpdateStatus(art.id, st)}
                            className={`flex-1 text-[11px] font-bold py-1.5 rounded-lg border capitalize transition-all ${
                              art.status === st
                                ? "bg-black text-white shadow-sm border-black"
                                : "bg-white hover:bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => startEditing(art)}
                          className="flex-1 bg-white hover:bg-gray-100 border border-gray-200 text-neutral-800 text-xs py-2 font-semibold rounded-lg transition-colors"
                        >
                          ✏️ Modify Item
                        </button>
                        <button
                          onClick={() => handleDelete(art.id)}
                          className="bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 px-3 py-2 text-xs font-semibold rounded-lg transition-colors"
                        >
                          🗑️ Delete
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              <div className="divide-y divide-gray-100">
                {filteredAndSortedArtworks.map((art) => (
                  <div
                    key={art.id}
                    className="p-4 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-xl bg-gray-100 overflow-hidden flex-shrink-0">
                        {art.image_url?.length > 0 ? (
                          <img
                            src={art.image_url[0]}
                            alt={art.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-[9px] text-gray-400">
                            🖼️
                          </div>
                        )}
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-gray-900">
                          {art.title}
                        </h4>
                        <p className="text-xs text-gray-500 mt-0.5 line-clamp-1 max-w-md">
                          {art.description || "No descriptions detailed."}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                      <div className="text-right">
                        <span className="font-bold text-sm block">
                          €{art.price}
                        </span>
                        <span
                          className={`text-[10px] font-bold uppercase ${
                            art.status === "available"
                              ? "text-emerald-600"
                              : art.status === "reserved"
                              ? "text-amber-600"
                              : "text-red-600"
                          }`}
                        >
                          {art.status === "reserved" || art.status === "sold"
                            ? art.reservation_info || art.status
                            : art.status}
                        </span>
                      </div>
                      {isAdmin && (
                        <div className="flex gap-1">
                          <button
                            onClick={() => startEditing(art)}
                            className="p-2 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 text-xs"
                            title="Edit"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDelete(art.id)}
                            className="p-2 bg-red-50 border border-red-100 rounded-lg hover:bg-red-100 text-xs"
                            title="Delete"
                          >
                            🗑️
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* LIGHTBOX UTILITY COMPONENT MODAL */}
      {selectedLightboxImage && (
        <div
          className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-fadeIn cursor-zoom-out"
          onClick={() => setSelectedLightboxImage(null)}
        >
          <img
            src={selectedLightboxImage}
            alt="Enlarged Canvas View"
            className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl transition-transform duration-300"
          />
        </div>
      )}

      {/* EDIT MODAL SYSTEM */}
      {isAdmin && editingArtwork && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-[90] flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-gray-100 overflow-hidden max-h-[90vh] flex flex-col animate-scaleUp">
            <div className="px-6 py-4 bg-gray-50 border-b flex justify-between items-center">
              <h3 className="font-bold text-base text-gray-900">
                ✏️ Modify Listing Parameters
              </h3>
              <button
                onClick={() => setEditingArtwork(null)}
                className="text-gray-400 hover:text-black transition-colors"
              >
                ✕
              </button>
            </div>

            <form
              onSubmit={handleSaveChanges}
              className="p-6 overflow-y-auto space-y-4 flex-1"
            >
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Title
                </label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                    Price (€)
                  </label>
                  <input
                    type="number"
                    value={editPrice}
                    onChange={(e) => setEditPrice(e.target.value)}
                    className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none text-sm"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                    Status
                  </label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value)}
                    className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none h-[48px] text-sm"
                  >
                    <option value="available">Available</option>
                    <option value="reserved">Reserved</option>
                    <option value="sold">Sold</option>
                  </select>
                </div>
              </div>

              <div className="space-y-3 bg-gray-50 p-4 rounded-xl border border-gray-100">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Item Metadata
                </p>
                <input
                  type="text"
                  value={editMedium}
                  onChange={(e) => setEditMedium(e.target.value)}
                  className="w-full p-2 bg-white border rounded-lg text-xs"
                  placeholder="Medium (e.g. Oil on Canvas)"
                />
                <input
                  type="text"
                  value={editDimensions}
                  onChange={(e) => setEditDimensions(e.target.value)}
                  className="w-full p-2 bg-white border rounded-lg text-xs"
                  placeholder="Dimensions (e.g. 80x100cm)"
                />
                <input
                  type="text"
                  value={editYear}
                  onChange={(e) => setEditYear(e.target.value)}
                  className="w-full p-2 bg-white border rounded-lg text-xs"
                  placeholder="Year Production"
                />
              </div>

              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Description
                </label>
                <textarea
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl h-24 resize-none focus:outline-none text-sm"
                />
              </div>

              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 block mb-2">
                  Image Attachments
                </label>
                <div className="flex flex-wrap gap-2 mb-3">
                  {editExistingUrls.map((url, index) => (
                    <div
                      key={index}
                      className="w-16 h-16 rounded-xl overflow-hidden relative border border-gray-200 bg-gray-100 group"
                    >
                      <img
                        src={url}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setEditExistingUrls((prev) =>
                            prev.filter((_, idx) => idx !== index)
                          )
                        }
                        className="absolute inset-0 bg-black/60 text-white font-bold opacity-0 group-hover:opacity-100 transition-all text-xs flex items-center justify-center"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>

                <div
                  onClick={() => editFileInputRef.current?.click()}
                  className="p-4 bg-gray-50 border border-dashed rounded-xl flex items-center justify-center cursor-pointer hover:bg-gray-100"
                >
                  <span className="text-xs text-gray-500 font-medium">
                    {editImageFiles.length > 0
                      ? `Added +${editImageFiles.length} new images`
                      : "➕ Upload Additional Images"}
                  </span>
                  <input
                    ref={editFileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) =>
                      e.target.files &&
                      setEditImageFiles(Array.from(e.target.files))
                    }
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t">
                <button
                  type="button"
                  onClick={() => setEditingArtwork(null)}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 p-3 rounded-xl font-medium text-sm transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-black text-white p-3 rounded-xl font-medium hover:bg-neutral-800 disabled:bg-neutral-400 transition-colors text-sm"
                >
                  {loading ? "Saving Changes..." : "Save Changes"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
