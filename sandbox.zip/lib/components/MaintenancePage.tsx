"use strict";
"use client";

import { useEffect, useState } from "react";

interface MaintenancePageProps {
  onAdminOverrideClick: () => void;
}

export default function MaintenancePage({ onAdminOverrideClick }: MaintenancePageProps) {
  const [hoursLeft, setHoursLeft] = useState<string>("00");
  const [minutesLeft, setMinutesLeft] = useState<string>("00");
  const [secondsLeft, setSecondsLeft] = useState<string>("00");
  const [progressPercent, setProgressPercent] = useState<number>(100);
  const [statusMessage, setStatusMessage] = useState<string>("Initializing System Block...");

  useEffect(() => {
    const runTimerEngine = () => {
      const isLockdownActive = localStorage.getItem("sys_maintenance_lockdown") === "true";
      const savedStartTime = localStorage.getItem("sys_maintenance_start_time");
      const savedEndTime = localStorage.getItem("sys_maintenance_end_time");
      
      const now = Date.now();

      // SCENARIO A: FUTURE SCHEDULED TIMEFRAME PIPELINE
      if (!isLockdownActive && savedStartTime && savedEndTime) {
        const startTime = new Date(savedStartTime).getTime();
        
        if (now < startTime) {
          setStatusMessage("System Notice: Upstream Maintenance Pipeline Queued");
          const diffToStart = startTime - now;
          
          const hours = Math.floor(diffToStart / (1000 * 60 * 60));
          const minutes = Math.floor((diffToStart % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((diffToStart % (1000 * 60)) / 1000);

          setHoursLeft(String(hours).padStart(2, "0"));
          setMinutesLeft(String(minutes).padStart(2, "0"));
          setSecondsLeft(String(seconds).padStart(2, "0"));
          setProgressPercent(100);
          return true;
        } else {
          localStorage.setItem("sys_maintenance_lockdown", "true");
        }
      }

      // SCENARIO B: ACTIVE RUNNING LOCKDOWN
      if (!savedEndTime) {
        setStatusMessage("Emergency Operations: Indefinite Structural Lockdown");
        setHoursLeft("--");
        setMinutesLeft("--");
        setSecondsLeft("--");
        setProgressPercent(100);
        return false;
      }

      const startTime = savedStartTime ? new Date(savedStartTime).getTime() : (now - 3600000); // 1hr fallback start
      const targetEndTime = new Date(savedEndTime).getTime();
      const totalDuration = targetEndTime - startTime;
      const difference = targetEndTime - now;

      if (difference <= 0) {
        setStatusMessage("Synergy Rebuilt. Restoring Live Server Grid...");
        setHoursLeft("00");
        setMinutesLeft("00");
        setSecondsLeft("00");
        setProgressPercent(0);
        
        localStorage.setItem("sys_maintenance_lockdown", "false");
        localStorage.removeItem("sys_maintenance_start_time");
        localStorage.removeItem("sys_maintenance_end_time");
        localStorage.removeItem("sys_maintenance_eta");

        setTimeout(() => {
          window.location.reload();
        }, 1200);
        return false;
      }

      setStatusMessage("Active Maintenance Node Online // Updating Elements");
      
      // Calculate split values
      const hours = Math.floor(difference / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setHoursLeft(String(hours).padStart(2, "0"));
      setMinutesLeft(String(minutes).padStart(2, "0"));
      setSecondsLeft(String(seconds).padStart(2, "0"));

      // Calculate progress percentage bar metrics
      const computedPercentage = Math.max(0, Math.min(100, (difference / totalDuration) * 100));
      setProgressPercent(computedPercentage);
      return true;
    };

    runTimerEngine();
    const clockLoop = setInterval(runTimerEngine, 1000);
    return () => clearInterval(clockLoop);
  }, []);

  return (
    <div className="min-h-screen w-full bg-neutral-950 text-white flex flex-col items-center justify-center p-6 relative select-none font-sans overflow-hidden">
      
      {/* STEALTH BYPASS TERMINAL TRIGGER */}
      <div className="absolute top-6 left-6 z-50">
        <button
          onClick={onAdminOverrideClick}
          className="text-xl opacity-20 hover:opacity-100 hover:scale-110 active:scale-95 transition-all focus:outline-none"
        >
          🎨
        </button>
      </div>

      <div className="max-w-xl w-full text-center space-y-8 relative z-10">
        
        {/* CORE TELEMETRY BANNER HEAD */}
        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono text-[10px] uppercase font-bold px-3 py-1 rounded-full tracking-widest animate-pulse">
            <span>⚠️</span> {statusMessage}
          </div>
          <h1 className="text-2xl font-black tracking-widest text-white uppercase font-mono">
            Undergoing Node Upgrades
          </h1>
          <p className="text-xs text-neutral-400 max-w-md mx-auto">
            System configuration assets are refreshing across production databases. Core live services will automatically resume on checkout.
          </p>
        </div>

        {/* DYNAMIC DIGITAL CLOCK GLASS CARDS BOX */}
        <div className="grid grid-cols-3 gap-3 font-mono">
          <div className="bg-neutral-900/40 border border-neutral-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl relative overflow-hidden group">
            <div className="text-3xl font-black tracking-tight text-neutral-100 tabular-nums">{hoursLeft}</div>
            <div className="text-[9px] uppercase font-bold tracking-widest text-neutral-500 mt-1">Hours</div>
            <div className="absolute inset-0 bg-gradient-to-t from-white/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-all pointer-events-none" />
          </div>

          <div className="bg-neutral-900/40 border border-neutral-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl relative overflow-hidden group">
            <div className="text-3xl font-black tracking-tight text-amber-400 tabular-nums">{minutesLeft}</div>
            <div className="text-[9px] uppercase font-bold tracking-widest text-neutral-500 mt-1">Minutes</div>
            <div className="absolute inset-0 bg-gradient-to-t from-amber-400/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-all pointer-events-none" />
          </div>

          <div className="bg-neutral-900/40 border border-neutral-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl relative overflow-hidden group">
            <div className="text-3xl font-black tracking-tight text-neutral-100 tabular-nums">{secondsLeft}</div>
            <div className="text-[9px] uppercase font-bold tracking-widest text-neutral-500 mt-1">Seconds</div>
            <div className="absolute inset-0 bg-gradient-to-t from-white/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-all pointer-events-none" />
          </div>
        </div>

        {/* METRIC GRAPHIC PROGRESS BAR CONTAINER */}
        <div className="space-y-2">
          <div className="w-full h-1.5 bg-neutral-900 border border-neutral-800/60 rounded-full overflow-hidden p-[1px]">
            <div 
              className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all duration-1000 ease-out shadow-[0_0_12px_rgba(245,158,11,0.4)]"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <div className="flex items-center justify-between font-mono text-[9px] uppercase tracking-wider text-neutral-500 px-1">
            <span>Terminal Core Init</span>
            <span>Est Completion Sync</span>
          </div>
        </div>

        {/* FOOTER WATERMARK BRANDING */}
        <div className="pt-4 opacity-15">
          <span className="text-xs font-black tracking-widest uppercase text-white font-mono">
            Just Kishibe Artwork
          </span>
        </div>
      </div>

      {/* GIANT LAYERED CANVAS DECAL BACKDROP */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.015] select-none overflow-hidden">
        <div className="text-[13vw] font-black tracking-tighter text-white uppercase text-center leading-none">
          KISHIBE<br />ARTWORK
        </div>
      </div>

    </div>
  );
}