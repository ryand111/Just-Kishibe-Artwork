"use strict";
"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import MaintenancePage from "./MaintenancePage"; 

interface AdminRecord {
  email: string;
  createdBy: string;
  createdAt: string;
  expiresAt: number | null;
}

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const [isMounted, setIsMounted] = useState(false);
  
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [isTerminalUnlocked, setIsTerminalUnlocked] = useState(false);

  // System Terminal Activation states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [adminEmailInput, setAdminEmailInput] = useState("");
  const [passkeyInput, setPasskeyInput] = useState("");
  const [modalError, setModalError] = useState<string | null>(null);

  // Hardcoded Absolute System Owners
  const systemOwners = [
    "ryandunne2011@gmail.com",
    "sophiatoader22@gmail.com",
    "rohankishibe222324@gmail.com"
  ];

  const [authorizedAdmins, setAuthorizedAdmins] = useState<AdminRecord[]>([]);
  const [isMaintenanceMode, setIsMaintenanceMode] = useState(false);
  const [maintenanceEta, setMaintenanceEta] = useState<string>("");
  const [systemPasskey, setSystemPasskey] = useState("Just Kishibe Artwork");
  const [motdBroadcast, setMotdBroadcast] = useState("");
  const [liveEtaString, setLiveEtaString] = useState<string>("—");

  useEffect(() => {
    setIsMounted(true);

    const savedLockdown = localStorage.getItem("sys_maintenance_lockdown") === "true";
    const savedEta = localStorage.getItem("sys_maintenance_eta") || "";
    
    setIsMaintenanceMode(savedLockdown);
    setMaintenanceEta(savedEta);
    
    setSystemPasskey(localStorage.getItem("sys_dynamic_passkey") || "Just Kishibe Artwork");
    setMotdBroadcast(localStorage.getItem("sys_motd_broadcast") || "");
    
    const savedAdmins = localStorage.getItem("system_structural_admins");
    if (savedAdmins) {
      try { setAuthorizedAdmins(JSON.parse(savedAdmins)); } catch (e) {}
    }

    if (localStorage.getItem("terminal_unlocked") === "true") {
      setIsTerminalUnlocked(true);
    }

    supabase.auth.getSession().then(({ data: { session } }) => {
      const email = session?.user?.email || localStorage.getItem("sb-mock-admin-email");
      if (email) setUserEmail(email.toLowerCase().trim());
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      const email = session?.user?.email || localStorage.getItem("sb-mock-admin-email");
      if (email) {
        setUserEmail(email.toLowerCase().trim());
      } else {
        setIsTerminalUnlocked(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!isMounted) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const savedEta = localStorage.getItem("sys_maintenance_eta") || "";
      const latestLockdownValue = localStorage.getItem("sys_maintenance_lockdown") === "true";
      
      let targetTime = 0;
      if (savedEta) targetTime = new Date(savedEta).getTime();

      // Future Check
      if (savedEta && !latestLockdownValue && now >= targetTime) {
        localStorage.setItem("sys_maintenance_lockdown", "true");
        setIsMaintenanceMode(true);
        window.location.reload();
        return;
      }

      // Auto-lift Check
      if (latestLockdownValue && savedEta && now >= targetTime) {
        localStorage.removeItem("sys_maintenance_eta");
        localStorage.removeItem("sys_motd_broadcast");
        localStorage.setItem("sys_maintenance_lockdown", "false");
        setIsMaintenanceMode(false);
        window.location.href = "/";
        return;
      }

      if (latestLockdownValue !== isMaintenanceMode) {
        setIsMaintenanceMode(latestLockdownValue);
        setMaintenanceEta(savedEta);
      }

      if (savedEta) {
        const difference = targetTime - now;
        if (difference <= 0) {
          setLiveEtaString("Resolving...");
        } else {
          const totalSecs = Math.floor(difference / 1000);
          const mins = Math.floor((totalSecs / 60) % 60);
          const hours = Math.floor((totalSecs / 3600) % 24);
          const days = Math.floor(totalSecs / 86400);
          setLiveEtaString(`${days > 0 ? days+'d ' : ''}${hours > 0 ? hours+'h ' : ''}${mins}m ${totalSecs % 60}s`);
        }
      } else {
        setLiveEtaString("—");
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isMounted, isMaintenanceMode]);

  const currentEmailClean = userEmail?.toLowerCase().trim() || "";
  const hasAccessClearance = systemOwners.includes(currentEmailClean) || authorizedAdmins.some(a => a.email === currentEmailClean);

  const shouldHideNavbar = isMaintenanceMode && !hasAccessClearance;

  const handleModalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError(null);
    const checkEmail = adminEmailInput.toLowerCase().trim();
    if (!systemOwners.includes(checkEmail) && !authorizedAdmins.some(a => a.email === checkEmail)) {
      setModalError("Access Denied.");
      return;
    }
    if (passkeyInput !== systemPasskey) {
      setModalError("Invalid System Passkey.");
      return;
    }
    localStorage.setItem("terminal_unlocked", "true");
    localStorage.setItem("sb-mock-admin-email", checkEmail);
    setIsTerminalUnlocked(true);
    setUserEmail(checkEmail);
    setIsModalOpen(false);
    router.push("/admin/dashboard");
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem("terminal_unlocked");
    localStorage.removeItem("sb-mock-admin-email");
    setUserEmail(null);
    setIsTerminalUnlocked(false);
    window.location.reload();
  };

  return (
    <>
      {/* MOTD Alert Broadcast Banner */}
      {isMounted && motdBroadcast && !shouldHideNavbar && (
        <div className="w-full bg-white text-neutral-900 text-center text-xs font-bold py-2 px-4 border-b border-gray-200 relative z-10">
          📢 <span className="truncate">{motdBroadcast}</span>
        </div>
      )}

      {/* Main Navbar */}
      {!shouldHideNavbar && (
        <nav className="w-full bg-white border-b border-gray-100 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
            
            <div className="flex items-center gap-2 min-w-[240px]">
              <a href="/" className="text-xl font-black tracking-tighter text-black">Just Kishibe Artwork</a>
              <button onClick={() => setIsModalOpen(true)} className="text-xl hover:scale-110 active:scale-95 transition-transform pl-1 focus:outline-none">🎨</button>
              
              {isMounted && hasAccessClearance && isTerminalUnlocked && (
                <button
                  onClick={() => router.push("/admin/dashboard")}
                  className="ml-3 text-[10px] uppercase font-bold tracking-widest px-2.5 py-1 rounded-md border bg-neutral-950 border-neutral-950 text-white hover:bg-neutral-800"
                >
                  👑 Owner Suite
                </button>
              )}
            </div>

            <div className="hidden md:flex items-center gap-8 text-sm font-semibold text-neutral-700">
              <a href="/" className={`hover:text-black transition-colors ${pathname === "/" ? "text-black border-b-2 border-black pt-1 pb-0.5" : ""}`}>Home</a>
              <a href="/about" className={`hover:text-black transition-colors ${pathname === "/about" ? "text-black border-b-2 border-black pt-1 pb-0.5" : ""}`}>About</a>
              <a href="/shop" className={`hover:text-black transition-colors ${pathname === "/shop" ? "text-black border-b-2 border-black pt-1 pb-0.5" : ""}`}>Shop</a>
              <a href="/commissions" className={`hover:text-black transition-colors ${pathname === "/commissions" ? "text-black border-b-2 border-black pt-1 pb-0.5" : ""}`}>Commissions</a>
            </div>

            <div className="flex items-center gap-4 min-w-[240px] justify-end">
              {userEmail ? (
                <div className="flex items-center gap-3 bg-gray-50 p-1.5 pl-3.5 rounded-full border border-gray-200">
                  <span className="text-xs font-medium text-neutral-600 max-w-[140px] truncate">{userEmail}</span>
                  <button onClick={handleLogout} className="bg-white text-xs font-bold text-neutral-800 px-3 py-1.5 rounded-full border border-neutral-200 hover:bg-neutral-900 transition-all">Log Out</button>
                </div>
              ) : (
                <a href="/register" className="bg-neutral-950 text-white text-xs font-bold px-4 py-2 rounded-full shadow-sm">Create Account</a>
              )}
            </div>

          </div>
        </nav>
      )}

      {/* Maintenance Page Render Overrides */}
      {isMounted && isMaintenanceMode && !hasAccessClearance && (
        <MaintenancePage 
          maintenanceEta={maintenanceEta}
          liveEtaString={liveEtaString}
          onAdminOverrideClick={() => setIsModalOpen(true)}
        />
      )}

      {/* RE-AUTH OVERRIDE MODAL FRAME */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-xl z-[99999999] flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 p-6 rounded-3xl text-white relative shadow-2xl">
            <button onClick={() => setIsModalOpen(false)} className="absolute top-5 right-5 text-neutral-400 hover:text-white">✕</button>
            <div className="text-center space-y-1 mb-4">
              <h2 className="text-xl font-black tracking-tight">Terminal System Access</h2>
              <p className="text-xs text-neutral-400">Initialize security profile overrides</p>
            </div>
            <form onSubmit={handleModalSubmit} className="space-y-4">
              {modalError && <div className="text-xs text-red-400 bg-red-950/30 p-2.5 rounded-xl border border-red-900/50 text-center">{modalError}</div>}
              <div>
                <label className="text-[10px] font-bold uppercase text-neutral-400 block mb-1">System Profile Email</label>
                <input type="email" value={adminEmailInput} onChange={(e) => setAdminEmailInput(e.target.value)} className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-xl text-sm focus:outline-none" required />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-neutral-400 block mb-1">System Access Passkey</label>
                <input type="text" value={passkeyInput} onChange={(e) => setPasskeyInput(e.target.value)} className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-xl text-sm focus:outline-none" required />
              </div>
              <button type="submit" className="w-full bg-white text-black p-3 rounded-xl font-black text-sm hover:bg-neutral-200 transition-all">Authorize Bypass</button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}